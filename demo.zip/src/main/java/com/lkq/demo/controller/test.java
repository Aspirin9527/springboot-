package com.lkq.demo.controller;

import com.lkq.demo.service.DemoService;
import com.lkq.demo.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author lin
 * @date 2022年02月08日 11:22
 */
@RestController
public class test {

    @Autowired
    DemoService demoService;

    @GetMapping("/test")
    public String test(){
        return RedisUtil.get("key",0);
    }

}
