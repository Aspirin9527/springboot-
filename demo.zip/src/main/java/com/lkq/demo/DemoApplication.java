package com.lkq.demo;

import com.lkq.demo.configuration.RedisSource;
import com.lkq.demo.utils.RedisUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	@ConditionalOnExpression("${ddos.redis.start:true}")
	public RedisUtil redisUtil(RedisSource redisSource){
		RedisUtil.init(redisSource);
		return new RedisUtil();
	}
}
