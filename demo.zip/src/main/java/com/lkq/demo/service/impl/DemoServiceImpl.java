package com.lkq.demo.service.impl;

import com.lkq.demo.dao.DemoDao;
import com.lkq.demo.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author lin
 * @date 2022年02月08日 13:36
 */
@Service
public class DemoServiceImpl implements DemoService {

    @Autowired
    DemoDao demoDao;

    @Override
    public void add() {

    }

    @Override
    public List<Map<String, Object>> getAll() {
        return demoDao.getAll();
    }
}
