package com.lkq.demo.service;

import java.util.List;
import java.util.Map;

/**
 * @author lin
 * @date 2022年02月08日 13:35
 */
public interface DemoService {

    void add();

    List<Map<String,Object>> getAll();

}
