package com.lkq.demo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author lin
 * @date 2022年02月08日 13:41
 */
@Component
@Mapper
public interface DemoMapper {

   List<Map<String,Object>> getAll();
}
