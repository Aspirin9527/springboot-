package com.lkq.demo.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author lin
 * @date 2022年02月08日 15:40
 */
@ConfigurationProperties(prefix  = "redis")
@Component
@Data
public class RedisSource {
    private String host;
    private Integer port;
    private String password;	// redis密码
}
