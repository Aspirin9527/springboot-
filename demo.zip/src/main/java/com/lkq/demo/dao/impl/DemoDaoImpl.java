package com.lkq.demo.dao.impl;

import com.lkq.demo.dao.DemoDao;
import com.lkq.demo.mapper.DemoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author lin
 * @date 2022年02月08日 13:38
 */
@Repository
public class DemoDaoImpl implements DemoDao {

    @Autowired
    DemoMapper demoMapper;

    @Override
    public void add() {

    }

    @Override
    public List<Map<String, Object>> getAll() {
        return demoMapper.getAll();
    }

}
