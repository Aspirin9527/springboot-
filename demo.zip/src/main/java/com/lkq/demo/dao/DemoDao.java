package com.lkq.demo.dao;

import java.util.List;
import java.util.Map;

/**
 * @author lin
 * @date 2022年02月08日 13:37
 */
public interface DemoDao {

    void add();

    List<Map<String,Object>> getAll();
}
