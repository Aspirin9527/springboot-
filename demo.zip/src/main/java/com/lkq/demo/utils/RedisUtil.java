/**
 * Copyright (c) 2008-2015 浩瀚深度 All Rights Reserved.
 * 
 * <p>FileName: RedisUtil.java</p>
 * 
 *
 * @author fanqiong
 * @date 2017年9月18日
 * @version 1.0
 * History:
 * v1.0.0, 范琼, 2017年9月18日, Create
 */
package com.lkq.demo.utils;

import com.alibaba.druid.util.StringUtils;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lkq.demo.configuration.RedisSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.io.IOException;
import java.util.*;

/**
 * <p>Title: RedisUtil</p>
 * <p>Description:Redis操作工具类 </p>
 * @author fanqiong
 * @date 2017年9月18日
 */
public class RedisUtil {

	private static Logger logger = LoggerFactory.getLogger(RedisUtil.class);
	/**
	 * 线程安全
	 */
	private static JedisPool[] cachePool;

	private final static int DEFALTDATABASE = 0;
	private final static int FOURTHDATABASE = 4;

	/**
	 * 
	 * <p>Title: init</p>
	 * <p>Description: </p>
	 * 初始化连接池
	 */
	public static void init(RedisSource support){
		logger.info("Redis连接池初始化开始");
		cachePool = buildPoolArray(support);
		logger.info("Redis连接池初始化完成, 连接地址：" + support.getHost());
	}
	
	private static JedisPool[] buildPoolArray(RedisSource support){

		JedisPool[] poolArray = new JedisPool[6];
		poolArray[0]=buildPool(0,support);
		poolArray[1]=buildPool(1,support);
		poolArray[2]=buildPool(2,support);
		poolArray[3]=buildPool(3,support);
		poolArray[4]=buildPool(4,support);
		poolArray[5]=buildPool(5,support);
		return poolArray;
	}
	
	private static JedisPool buildPool(int database,RedisSource support) {
		JedisPoolConfig config = new JedisPoolConfig();
		//连接耗尽时是否阻塞, false报异常,ture阻塞直到超时, 默认true
		config.setBlockWhenExhausted(true);
		//设置的逐出策略类名, 默认DefaultEvictionPolicy(当连接超过最大空闲时间,或连接数超过最大空闲连接数)
		config.setEvictionPolicyClassName("org.apache.commons.pool2.impl.DefaultEvictionPolicy");
		//是否启用pool的jmx管理功能, 默认true
		config.setJmxEnabled(true);
		//MBean ObjectName = new ObjectName("org.apache.commons.pool2:type=GenericObjectPool,name=" + "pool" + i); 默 认为"pool", JMX不熟,具体不知道是干啥的...默认就好.
		config.setJmxNamePrefix("pool");
		//是否启用后进先出, 默认true
		config.setLifo(true);
		//最大空闲连接数, 默认8个
		config.setMaxIdle(8);
		//最大连接数, 默认8个
		config.setMaxTotal(100);
		//获取连接时的最大等待毫秒数(如果设置为阻塞时BlockWhenExhausted),如果超时就抛异常, 小于零:阻塞不确定的时间,  默认-1
		config.setMaxWaitMillis(-1);
		//逐出连接的最小空闲时间 默认1800000毫秒(30分钟)
		config.setMinEvictableIdleTimeMillis(1800000);
		//最小空闲连接数, 默认0
		config.setMinIdle(5);
		//每次逐出检查时 逐出的最大数目 如果为负数就是 : 1/abs(n), 默认3
		config.setNumTestsPerEvictionRun(3); 
		//对象空闲多久后逐出, 当空闲时间>该值 且 空闲连接>最大空闲数 时直接逐出,不再根据MinEvictableIdleTimeMillis判断  (默认逐出策略)   
		config.setSoftMinEvictableIdleTimeMillis(1800000);
		//在获取连接的时候检查有效性, 默认false
		config.setTestOnBorrow(false);
		//在空闲时检查有效性, 默认false
		config.setTestWhileIdle(false);
		//逐出扫描的时间间隔(毫秒) 如果为负数,则不运行逐出线程, 默认-1
		config.setTimeBetweenEvictionRunsMillis(-1);
		int timeout=5000;
		String password = support.getPassword();
		if("null".equals(password) || StringUtils.isEmpty(password)) {
			password = null;
		}
		JedisPool pool = new JedisPool(config,
				support.getHost(),
				support.getPort(),timeout,password,database);
//		JedisPool pool = new JedisPool(config,
//		 		"172.16.20.128",6379,timeout,null,database);
		return pool;
	}

	/**
	 * 
	 * <p>Title: getPool</p>
	 * <p>Description:获取Jedis默认连接池 </p>
	 * @return
	 */
	public static JedisPool getPool(int database){
		return cachePool[database];
	}


	/**
	 * 
	 * <p>Title: returnResource</p>
	 * <p>Description:返回资源 </p>
	 * @param jedis
	 */
	public static void returnResource(Jedis jedis) {  
	    if (jedis != null) {  
	         jedis.close();
	    }  
	}  
	
	/**
	 * 
	 * <p>Title: getJedis</p>
	 * <p>Description:获取Jedis实例 </p>
	 * @return
	 * @throws Exception
	 */
	public static Jedis getJedis(int database) throws Exception {  
	    Jedis jedis = null; 
	    jedis =  getPool(database).getResource(); 
	    return jedis;
	}

	public static String ping() {
		String pong = null;
		Jedis jedis = null;
		try {
			jedis= getJedis(DEFALTDATABASE);
			pong = jedis.ping();
		} catch(Exception e){
			e.printStackTrace();
		} finally {
			returnResource(jedis);
		}
		return pong;
	}

	/**
	 * 
	 * <p>Title: get</p>
	 * <p>Description:得到值 </p>
	 * @param key
	 * @return
	 */
	public static String get(String key,int database) {  
	    String value = null;  
	    Jedis jedis = null;
	    try {
	        jedis= getJedis(database);
	        value = jedis.get(key); 
	    } catch(Exception e){
//	        if(jedis != null){
//	            jedis.close();
//	        }
	        e.printStackTrace();
	    } finally {
	        returnResource(jedis);  
	    }
	    return value;  
	}  

	/**
	 * 
	 * <p>Title: set</p>
	 * <p>Description: 设置键值</p>
	 * @param key
	 * @param value
	 * @return
	 */
	public static String set(String key,String value,int database) {
	     Jedis jedis = null;
	     String ans = null;
	     try {  
	         jedis = getJedis(database);  
	         ans = jedis.set(key,value);  
	     } catch (Exception e) {  
	         //释放redis对象  
//	         if(jedis != null){
//	             jedis.close();
//	         }
	         e.printStackTrace();  
	     } finally {  
	         //返还到连接池  
	         returnResource(jedis);  
	     }  
	     return ans;
	}

	/**
	 *
	 * <p>Title: set</p>
	 * <p>Description: 设置键值</p>
	 * @param key
	 * @param value
	 * @return
	 */
	public static String set(String key, byte[] value,int database) {
		Jedis jedis = null;
		String ans = null;
		try {
			jedis = getJedis(database);
			ans = jedis.set(key.getBytes("UTF-8"), value);
		} catch (Exception e) {
			//释放redis对象
//	         if(jedis != null){
//	             jedis.close();
//	         }
			e.printStackTrace();
		} finally {
			//返还到连接池
			returnResource(jedis);
		}
		return ans;
	}
	
	
	
	/**
	 * 
	 * <p>Title: getHash</p>
	 * <p>Description:获取hash类型的数据 </p>
	 * @return
	 */
	public static String getHash(String key,String field,int database) {
		 String value = null;  
		    Jedis jedis = null;
		    try {
		        jedis= getJedis(database);
		        value = jedis.hget(key, field);
		    } catch(Exception e){
//		        if(jedis != null){
//		            jedis.close();
//		        }
		        e.printStackTrace();
		    } finally {
		        returnResource(jedis);  
		    }
		    return value;  
	}
	
	/**
	 * 
	 * <p>Title: getMap</p>
	 * <p>Description: 获取map值</p>
	 * @param key
	 * @return
	 */
	public static Map<String, String> getMap(String key,int database) {
		Map<String, String> map = null;
		 Jedis jedis = null;
		    try {
		        jedis= getJedis(database);
		        map = jedis.hgetAll(key);
		    } catch(Exception e){
//		        if(jedis != null){
//		            jedis.close();
//		        }
		        e.printStackTrace();
		    } finally {
		        returnResource(jedis);  
		    }
		    return null == map ? new HashMap<>() : map;
	}
	
	/**
	 * 
	 * <p>Title: setField</p>
	 * <p>Description:设置map中单个field </p>
	 * @param key
	 * @param field
	 * @param value
	 * @return
	 */
	public static Long setField(String key, String field, String value,int database) {
		Jedis jedis = null;
	     Long ans = null;
	     try {  
	         jedis = getJedis(database);  
	         ans = jedis.hset(key, field, value);
	     } catch (Exception e) {  
	         //释放redis对象  
//	         if(jedis != null){
//	             jedis.close();
//	         }
	         e.printStackTrace();  
	     } finally {  
	         //返还到连接池  
	         returnResource(jedis);  
	     }  
	     return ans;
	}
	
	
	/**
	 * 
	 * <p>Title: setHash</p>
	 * <p>Description:存hash值 </p>
	 * @return
	 */
	public static String setHash(String key, Map<String, String> map,int database) {
		 Jedis jedis = null;
	     String ans = null;
	     try {  
	         jedis = getJedis(database);  
	         ans = jedis.hmset(key, map);
	     } catch (Exception e) {  
	         //释放redis对象  
//	         if(jedis != null){
//	             jedis.close();
//	         }
	         e.printStackTrace();  
	     } finally {  
	         //返还到连接池  
	         returnResource(jedis);  
	     }  
	     return ans;
	}
	
	/**
	 * 
	 * <p>Title: expire</p>
	 * <p>Description: 重新设置key的失效时长</p>
	 * @param key
	 * @param seconds
	 * @return
	 */
	public static Long expire(String key, int seconds,int database) {
		 Jedis jedis = null;
	     Long ans = null;
	     try {  
	         jedis = getJedis(database);  
	         ans = jedis.expire(key, seconds); 
	     } catch (Exception e) {  
//	         if(jedis != null){
//	            jedis.close();
//	         }
	        e.printStackTrace();  
	     } finally {  
	         //返还到连接池  
	         returnResource(jedis);  
	     }  
	     return ans;
	}
	
	/**
	 * 
	 * <p>Title: setex</p>
	 * <p>Description:设置键值并同时设置有效期 </p>
	 * @param key
	 * @param seconds 秒数
	 * @param value 
	 * @return
	 */
	public static String setex(String key,int seconds,String value,int database) {
	     Jedis jedis = null;
	     String ans = null;
	     try {  
	         jedis = getJedis(database);  
	         ans = jedis.setex(key,seconds,value);  
	     } catch (Exception e) {  
//	         if(jedis != null){
//	            jedis.close();
//	         }
	        e.printStackTrace();  
	     } finally {  
	         //返还到连接池  
	         returnResource(jedis);  
	     }  
	     return ans;
	}
	
	/**
	 * 
	 * <p>Title: String</p>
	 * <p>Description:缓存byte[] </p>
	 * @param key
	 * @param seconds
	 * @param value
	 */
	public static String setex(byte[] key, int seconds, byte[] value,int database) {
		 Jedis jedis = null;
	     String ans = null;
	     try {  
	         jedis = getJedis(database);  
	         ans = jedis.setex(key,seconds,value);  
	     } catch (Exception e) {  
//	         if(jedis != null){
//	            jedis.close();
//	         }
	        e.printStackTrace();  
	     } finally {  
	         //返还到连接池  
	         returnResource(jedis);  
	     }  
	     return ans;
	}
	
	/**
	 * 
	 * <p>Title: get</p>
	 * <p>Description:得到值 </p>
	 * @param key
	 * @return
	 */
	public static byte[] get(byte[] key,int database) {  
	    byte[] value = null;  
	    Jedis jedis = null;
	    try {
	        jedis= getJedis(database);
	        value = jedis.get(key);
	    } catch(Exception e){
//	        if(jedis != null){
//	            jedis.close();
//	        }
	        e.printStackTrace();
	    } finally {
	        returnResource(jedis);  
	    }
	    return value;  
	}

	/**
	 * 
	 * <p>Title: getKeys</p>
	 * <p>Description:获取到所有key的方法 </p>
	 * @return
	 */
	public static Set<String> getKeys(String pattern,int database) {
		Jedis jedis = null;
		Set<String> keys = null;
		  try {  
		         jedis = getJedis(database);  
		         keys = jedis.keys(pattern);  
		     } catch (Exception e) {  
//		         if(jedis != null){
//		            jedis.close();
//		         }
		        e.printStackTrace();  
		     } finally {  
		         //返还到连接池  
		         returnResource(jedis);  
		     }  
		  return keys;
	}
	/**
	 * 
	 * <p>Title: getKeys</p>
	 * <p>Description:获取到所有key的方法 </p>
	 * @return
	 */
	public static Set<byte[]> getKeys(byte[] pattern,int database) {
		Jedis jedis = null;
		Set<byte[]> keys = null;
		  try {  
		         jedis = getJedis(database);  
		         keys = jedis.keys(pattern);  
		     } catch (Exception e) {  
//		         if(jedis != null){
//		            jedis.close();
//		         }
		        e.printStackTrace();  
		     } finally {  
		         //返还到连接池  
		         returnResource(jedis);  
		     }  
		  return keys;
	}
	
	
	/**
	 * 
	 * <p>Title: exists</p>
	 * <p>Description:判断key是否存在 </p>
	 * @param key
	 * @return
	 */
	public static Boolean exists(String key,int database) {
	     Jedis jedis = null;  
	     try {  
	         jedis = getJedis(database);  
	         return jedis.exists(key);  
	     } catch (Exception e) {  
//	         if(jedis != null){
//	             jedis.close();
//	         }
	         e.printStackTrace();  
	         return false;
	     } finally {  
	        //返还到连接池  
	         returnResource(jedis);  
	     }  
	}
	
	/**
	 * 
	 * <p>Title: del</p>
	 * <p>Description:删除某个键 </p>
	 * @param keys
	 * @return
	 */
	public static Long del(int database,byte[]...keys) {
	     Jedis jedis = null;  
	     Long res = 0L;
	     try {  
	         jedis = getJedis(database);  
	         res = jedis.del(keys);
	     } catch (Exception e) {  
//	        if(jedis != null){
//	            jedis.close();
//	        }
	        e.printStackTrace();
	     } finally {  
	        //返还到连接池  
	        returnResource(jedis);  
	     }  
	     return res;
	}
	/**
	 * 
	 * <p>Title: del</p>
	 * <p>Description:删除某个键 </p>
	 * @param keys
	 * @return
	 */
	public static Long del(int database,String...keys) {
	     Jedis jedis = null;  
	     Long res = 0L;
	     try {  
	         jedis = getJedis(database);
	         res = jedis.del(keys);  
	     } catch (Exception e) {  
//	        if(jedis != null){
//	            jedis.close();
//	        }
	        e.printStackTrace();
	     } finally {  
	        //返还到连接池  
	        returnResource(jedis);  
	     }  
	     return res;
	}

	
	public static boolean idKeyExist(String key,int database) {
		if(exists(key,database)){
			return true;
		}else{
			return false;
		}	
	}
	@SuppressWarnings({ "unchecked", "rawtypes"})
	public static <T> T getCacheBean(String key,Class cls,int database) {
		String value = get(key,database);
		if(null != value) {
			return (T)toObject(value, cls);
		}
		return null;
	}
	/**
	 * 
	 * <p>Title: putCacheBean</p>
	 * <p>Description: </p>
	 * 存放bean对象
	 * @param id
	 * @param object
	 * @param database
	 */
	public static String putCacheBean(String id,  Object object,int database) {
		return set(id, toJSONStr(object),database);
	}
	/**
	 * 
	 * <p>Title: putCacheBean</p>
	 * <p>Description: </p>
	 * 存放bean对象，并设置过期时间
	 * @param id
	 * @param object
	 * @param database
	 */
	public static void putCacheBean(String id, Object object,int database,int expireTime) {
		RedisUtil.setex(id, expireTime, toJSONStr(object),database);
	}
	/**
	 * 
	 * <p>Title: toObject</p>
	 * <p>Description: json转obj</p>
	 * @param json
	 * @param cls
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object toObject(String json, Class cls){
		//logger.info("要转换的msg为:"+json);
		ObjectMapper mapper = new ObjectMapper();
		mapper.registerModule(new com.fasterxml.jackson.datatype.guava.GuavaModule());
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		Object ob = null;
       try {
       	ob = mapper.readValue(json, cls);
		} catch (Exception e) {
			e.printStackTrace();
		}
       return ob;
	}
	/**
	 * 
	 * <p>Title: toJSONStr</p>
	 * <p>Description: 对象转json</p>
	 * @param object
	 * @return
	 */
	public static String toJSONStr(Object object){
		String json = "";
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
			mapper.registerModule(new com.fasterxml.jackson.datatype.guava.GuavaModule());
			json = mapper.writeValueAsString(object);
			//logger.info("写入的msg为:"+json);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}
	/**
	 * 
	 * <p>Title: getCacheList</p>
	 * <p>Description: </p>
	 * 获取json并解析成list对象
	 * @param key
	 * @param database
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static<T> List<T> getCacheList(String key,int database,Class cls) {
		List<T> list = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String value = RedisUtil.get(key,database);
			if(null != value){
				JavaType javaType = mapper.getTypeFactory().constructParametricType(ArrayList.class, cls);
				list = mapper.readValue(value, javaType);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 *
	 * <p>Title: del</p>
	 * <p>Description: 向set中放置一个值 </p>
	 * @param key
	 * @param member
	 * @param database
	 * @return
	 */
	public static Long sadd(String key, String member, int database) {
		Jedis jedis = null;
		Long res = 0L;
		try {
			jedis = getJedis(database);
			res = jedis.sadd(key, member);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//返还到连接池
			returnResource(jedis);
		}
		return res;
	}

	/**
	 *
	 * <p>Title: del</p>
	 * <p>Description: 获取set大小 </p>
	 * @param key
	 * @param database
	 * @return
	 */
	public static Long scard(String key, int database) {
		Jedis jedis = null;
		Long res = 0L;
		try {
			jedis = getJedis(database);
			res = jedis.scard(key);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//返还到连接池
			returnResource(jedis);
		}
		return res;
	}

	public static void main(String[] args){
		RedisUtil.init(new RedisSource());
		for(int i=1;i<=10;i++){
			List<String> keys = new ArrayList<>();
			for(int j=0;j<10;j++){
				String key = String.valueOf(i) + "-"+String.valueOf(j);
				RedisUtil.set(key, "test".getBytes(), FOURTHDATABASE);
				keys.add(key);
			}
			RedisUtil.del(FOURTHDATABASE, keys.toArray(new String[keys.size()]));
			System.out.println("当前为第"+i+"次执行, 成功10条");
		}
		System.out.println("全部执行完成");
	}
}